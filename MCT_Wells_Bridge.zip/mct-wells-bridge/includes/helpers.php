<?php
if (!defined('ABSPATH')) exit;

function mctwb_sanitize_uid($uid) {
  $uid = strtoupper(trim((string)$uid));
  // Allow A-Z 0-9 _ - only
  $uid = preg_replace('/[^A-Z0-9_-]/', '', $uid);
  return $uid;
}
