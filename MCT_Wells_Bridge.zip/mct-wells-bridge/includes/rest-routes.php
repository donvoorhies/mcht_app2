<?php
if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
  register_rest_route('mct/v1', '/manifest', [
    'methods' => 'GET',
    'callback' => 'mctwb_rest_get_manifest',
    'permission_callback' => '__return_true',
  ]);

  register_rest_route('mct/v1', '/cards/(?P<uid>[A-Za-z0-9_-]+)', [
    'methods' => 'GET',
    'callback' => 'mctwb_rest_get_card_by_uid',
    'permission_callback' => '__return_true',
    'args' => [
      'uid' => [
        'required' => true,
        'sanitize_callback' => function ($v) { return mctwb_sanitize_uid($v); }
      ]
    ]
  ]);
});

function mctwb_rest_get_manifest(WP_REST_Request $req) {
  $opts = get_option(MCTWB_OPT_KEY, []);
  $appVersion = isset($opts['appVersion']) ? (string)$opts['appVersion'] : '0.1.0';
  $manifestRaw = isset($opts['manifest']) ? (string)$opts['manifest'] : '';

  $manifest = null;
  if ($manifestRaw) {
    $decoded = json_decode($manifestRaw, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
      $manifest = $decoded;
    }
  }

  // If no manifest saved, return a safe minimal default
  if (!$manifest) {
    $manifest = [
      'schemaVersion' => 'mct.manifest.v1',
      'appVersion' => $appVersion,
      'updatedAt' => gmdate('c'),
      'locale' => get_locale(),
      'hubs' => [],
      'nodes' => [],
      'appRoutes' => [
        ['id' => 'overview', 'title' => 'OVERBLIK', 'uiText' => ''],
        ['id' => 'info', 'title' => 'INFO', 'uiText' => ''],
      ],
    ];
  } else {
    // Ensure required fields exist / override server-controlled fields
    $manifest['schemaVersion'] = isset($manifest['schemaVersion']) ? $manifest['schemaVersion'] : 'mct.manifest.v1';
    $manifest['appVersion'] = $appVersion;
    $manifest['updatedAt'] = gmdate('c');
    if (!isset($manifest['locale'])) $manifest['locale'] = get_locale();
    if (!isset($manifest['hubs'])) $manifest['hubs'] = [];
    if (!isset($manifest['nodes'])) $manifest['nodes'] = [];
  }

  // Attach a lightweight index of available cards so the app can map UID -> title quickly.
  // Full content is fetched via /wp-json/mct/v1/cards/{uid}.
  $manifest['cardsIndex'] = mctwb_collect_cards_index();

  return rest_ensure_response($manifest);
}

function mctwb_rest_get_card_by_uid(WP_REST_Request $req) {
  $uid = mctwb_sanitize_uid($req->get_param('uid'));
  $post_id = mctwb_find_post_id_by_uid($uid);

  if (!$post_id) {
    return new WP_REST_Response(['error' => 'not_found', 'uid' => $uid], 404);
  }

  $post = get_post($post_id);
  if (!$post) {
    return new WP_REST_Response(['error' => 'not_found', 'uid' => $uid], 404);
  }

  // Render content like WP would (shortcodes, embeds, etc.)
  $content = apply_filters('the_content', $post->post_content);

  return rest_ensure_response([
    'uid' => $uid,
    'title' => get_the_title($post),
    'content' => $content,
    'modified' => get_post_modified_time('c', true, $post),
  ]);
}

if (!function_exists('mctwb_collect_cards_index')) {
function mctwb_collect_cards_index() {
  $q = new WP_Query([
    'post_type' => 'mct_card',
    'post_status' => ['publish', 'private', 'draft'],
    'posts_per_page' => -1,
    'orderby' => 'modified',
    'order' => 'DESC',
    'fields' => 'ids',
  ]);

  $cards = [];
  foreach ($q->posts as $post_id) {
    $uid = get_post_meta($post_id, MCTWB_UID_META, true);
    if (!$uid) continue;

    $cards[] = [
      'uid' => (string)$uid,
      'title' => get_the_title($post_id),
      'modified' => get_post_modified_time('c', true, $post_id),
      'status' => get_post_status($post_id),
    ];
  }
  return $cards;
}
}
