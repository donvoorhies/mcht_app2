<?php
if (!defined('ABSPATH')) exit;

if (!defined('MCTWB_UID_META')) define('MCTWB_UID_META', '_mct_uid');

add_action('add_meta_boxes', function () {
  add_meta_box(
    'mctwb_uid_box',
    'MCT Card UID',
    'mctwb_uid_box_render',
    'mct_card',
    'side',
    'high'
  );
});

function mctwb_uid_box_render($post) {
  $uid = get_post_meta($post->ID, MCTWB_UID_META, true);
  wp_nonce_field('mctwb_uid_save', 'mctwb_uid_nonce');

  echo '<p><label for="mctwb_uid"><strong>UID</strong></label></p>';
  echo '<input type="text" id="mctwb_uid" name="mctwb_uid" value="' . esc_attr($uid) . '" style="width:100%;" placeholder="E.g. CAS_INTRO" />';
  echo '<p style="margin-top:8px; font-size:12px; color:#555;">Used by the app to fetch this card via REST.</p>';
}

add_action('save_post_mct_card', function ($post_id) {
  if (!isset($_POST['mctwb_uid_nonce']) || !wp_verify_nonce($_POST['mctwb_uid_nonce'], 'mctwb_uid_save')) return;
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  if (!current_user_can('edit_post', $post_id)) return;

  $uid = isset($_POST['mctwb_uid']) ? mctwb_sanitize_uid($_POST['mctwb_uid']) : '';
  if ($uid === '') {
    delete_post_meta($post_id, MCTWB_UID_META);
    return;
  }

  // Enforce uniqueness
  $existing = mctwb_find_post_id_by_uid($uid);
  if ($existing && (int)$existing !== (int)$post_id) {
    set_transient('mctwb_uid_error_' . get_current_user_id(), 'UID already in use: ' . $uid, 30);
    delete_post_meta($post_id, MCTWB_UID_META);
    return;
  }

  update_post_meta($post_id, MCTWB_UID_META, $uid);
}, 10, 1);

add_action('admin_notices', function () {
  $msg = get_transient('mctwb_uid_error_' . get_current_user_id());
  if ($msg) {
    delete_transient('mctwb_uid_error_' . get_current_user_id());
    echo '<div class="notice notice-error"><p>' . esc_html($msg) . '</p></div>';
  }
});

function mctwb_find_post_id_by_uid($uid) {
  $q = new WP_Query([
    'post_type' => 'mct_card',
    'post_status' => ['publish', 'draft', 'private'],
    'posts_per_page' => 1,
    'fields' => 'ids',
    'meta_query' => [[
      'key' => MCTWB_UID_META,
      'value' => $uid,
      'compare' => '='
    ]]
  ]);
  return !empty($q->posts) ? (int)$q->posts[0] : 0;
}
