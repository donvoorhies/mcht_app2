<?php
if (!defined('ABSPATH')) exit;

if (!defined('MCTWB_OPT_KEY')) define('MCTWB_OPT_KEY', 'mctwb_settings');

add_action('admin_menu', function () {
  add_options_page(
    'MCT Wells Bridge',
    'MCT Wells Bridge',
    'manage_options',
    'mctwb-settings',
    'mctwb_settings_page'
  );
});

add_action('admin_init', function () {
  register_setting('mctwb_settings_group', MCTWB_OPT_KEY, [
    'type' => 'array',
    'sanitize_callback' => 'mctwb_sanitize_settings',
    'default' => [
      'appVersion' => '0.1.0',
      'manifest' => '',
    ]
  ]);
});

function mctwb_sanitize_settings($value) {
  $out = [];
  $out['appVersion'] = isset($value['appVersion']) ? sanitize_text_field($value['appVersion']) : '0.1.0';

  // manifest stored as raw JSON string; validated on output
  $out['manifest'] = isset($value['manifest']) ? (string)$value['manifest'] : '';
  return $out;
}

function mctwb_settings_page() {
  if (!current_user_can('manage_options')) return;

  $opts = get_option(MCTWB_OPT_KEY, []);
  $appVersion = isset($opts['appVersion']) ? $opts['appVersion'] : '0.1.0';
  $manifest = isset($opts['manifest']) ? $opts['manifest'] : '';

  echo '<div class="wrap">';
  echo '<h1>MCT Wells Bridge</h1>';
  echo '<form method="post" action="options.php">';
  settings_fields('mctwb_settings_group');

  echo '<table class="form-table" role="presentation">';
  echo '<tr><th scope="row"><label for="mctwb_appVersion">App Version</label></th>';
  echo '<td><input name="'.esc_attr(MCTWB_OPT_KEY).'[appVersion]" id="mctwb_appVersion" type="text" value="'.esc_attr($appVersion).'" class="regular-text" /></td></tr>';

  echo '<tr><th scope="row"><label for="mctwb_manifest">Manifest (JSON)</label></th>';
  echo '<td>';
  echo '<textarea name="'.esc_attr(MCTWB_OPT_KEY).'[manifest]" id="mctwb_manifest" rows="18" class="large-text code" placeholder=\'{ \"schemaVersion\":\"mct.manifest.v1\", \"hubs\":[], \"nodes\":[] }\'>' . esc_textarea($manifest) . '</textarea>';
  echo '<p class="description">Paste manifest JSON here. The app fetches it from <code>/wp-json/mct/v1/manifest</code>.</p>';
  echo '</td></tr>';

  echo '</table>';

  submit_button();
  echo '</form>';
  echo '</div>';
}
