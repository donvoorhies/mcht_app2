<?php
if (!defined('ABSPATH')) exit;

function mctwb_register_cpt() {
  register_post_type('mct_card', [
    'label' => 'MCT Cards',
    'public' => false,
    'show_ui' => true,
    'show_in_menu' => true,
    'menu_icon' => 'dashicons-index-card',
    'supports' => ['title', 'editor', 'revisions'],
    'show_in_rest' => true,
    'rest_base' => 'mct_card',
    'capability_type' => 'post',
    'map_meta_cap' => true,
  ]);
}
