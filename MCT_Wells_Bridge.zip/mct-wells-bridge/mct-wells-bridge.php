<?php
/**
 * Plugin Name: MCT Wells Bridge
 * Description: CPT for MCT cards + UID + Manifest + REST endpoints for a React Native WebView app.
 * Version: 0.1.0
 * Author: Your Team
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) exit;

define('MCTWB_VERSION', '0.1.0');
define('MCTWB_PATH', plugin_dir_path(__FILE__));
define('MCTWB_URL', plugin_dir_url(__FILE__));

require_once MCTWB_PATH . 'includes/helpers.php';
require_once MCTWB_PATH . 'includes/cpt-mct-card.php';
require_once MCTWB_PATH . 'includes/meta-uid.php';
require_once MCTWB_PATH . 'includes/admin-settings.php';
require_once MCTWB_PATH . 'includes/rest-routes.php';

register_activation_hook(__FILE__, function () {
  mctwb_register_cpt();
  flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function () {
  flush_rewrite_rules();
});

add_action('init', function () {
  mctwb_register_cpt();
});
